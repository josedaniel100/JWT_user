export const jwtConstants = {
  secret: 'Clavesecreta123',
};
