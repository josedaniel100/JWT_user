export class User {
  _id: string;
  nombre_usuario: string;
  edad: number;
  nombre: string;
  password: string;
}
